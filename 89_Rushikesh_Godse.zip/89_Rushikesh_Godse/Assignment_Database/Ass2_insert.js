let data={
    host:"localhost",
    user:"root",
    password:"cdac",
    database:"godse",
    port:3306
};
let itemno=10;
let itemname="keyboard";
let price=80;
let category="Office";
const mysql=require("mysql2");
const con=mysql.createConnection(data);
con.query("insert into item (itemno,itemname,price,category) values(?,?,?,?)",[itemno,itemname,price,category],(err,res1)=>{
    if(err){
        console.log(err);
    }else{
        console.log("Successful insertion"+res1.affectedRows);
    }

});